Input: input.xlsx
Output: pH_7 and pH_13

main.ipynb or main.py needs to be executed for generating the output. plot.py or second block in main.ipynb can be executed for plotting the coverages. 
