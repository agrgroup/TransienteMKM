from data_extract import *
from solver_settings import *
import os
import subprocess

import subprocess

for pH in pH_list:
    parent_folder ="" 
    parent_folder = parent_folder+'pH'+'_'+str(pH)
    parent_folder = parent_folder.rstrip('_')
    #make directory parent folder if it does not exist
    if not os.path.exists(parent_folder):
        os.makedirs(parent_folder)
        os.chdir(parent_folder) 
    else:
        os.chdir(parent_folder)

    for V in V_list:
        children_folder = 'V'+'_'+str(V)
        if not os.path.exists(children_folder):
            os.makedirs(children_folder)
            os.chdir(children_folder)
        else:
            os.chdir(children_folder)
        gases,concentrations,adsorbates,activity,Reactant1,Reactant2,Reactant3,Product1,Product2,Product3,Ea,Eb,P,rxn=data_extract(pH,V,"input_data.xlsx")
        # Create the input file
        inp_file = open('input_file.mkm','w')
        inp_file.write('&compounds\n\n')
        inp_file.write("#gas-phase compounds\n\n#Name; isSite; concentration\n\n")
        for compound,concentration in zip(gases,concentrations):
            inp_file.write("{:<15}; 0; {}\n".format(compound,concentration))

        inp_file.write("\n\n#adsorbates\n\n#Name; isSite; activity\n\n")   
        for compound,concentration in zip(adsorbates,activity):
            inp_file.write("{:<15}; 1; {}\n".format(compound,concentration))

        inp_file.write("\n#free sites on the surface \n\n")
        inp_file.write("#Name; isSite; activity\n\n")   
        inp_file.write("*; 1; {}\n\n".format(1.0))    

        inp_file.write('&reactions\n\n')
        pre_exp=6.21e12
        for j in range(len(rxn)):
            if Reactant3[j]!="":
                line = "AR; {:<15} + {:<15} + {:<5} => {:<15}{:<15};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],Reactant2[j],Reactant3[j],Product1[j],Product2[j],pre_exp, pre_exp, Ea[j],Eb[j] )   
            elif Product3[j]!="":
                line = "AR; {:<15} + {:<14}  => {:<10} + {:<15} + {:<7};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],Reactant2[j],Product1[j],Product2[j],Product3[j],pre_exp, pre_exp, Ea[j],Eb[j] )     
            elif  Reactant2[j]!="" and Product2[j]!="":
                line = "AR; {:<15} + {:<15} => {:<15} + {:<20};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],Reactant2[j],Product1[j],Product2[j],pre_exp, pre_exp, Ea[j],Eb[j] )
            elif  Reactant2[j]=="" and Product2[j]!="":
                line = "AR; {:<15} {:<17} => {:<15} + {:<20};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],"",Product1[j],Product2[j],pre_exp, pre_exp, Ea[j],Eb[j] )
            elif Reactant2[j]!="" and Product2[j]=="":
                line = "AR; {:<15} + {:<15} => {:<15}{:<23};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],Reactant2[j],Product1[j],"",pre_exp, pre_exp, Ea[j],Eb[j] )
            elif Reactant2[j]=="" and Product2[j]=="":
                line = "AR; {:<15} {:<17} => {:<15}{:<23};{:<10.2e} ;  {:<10.2e} ;  {:<10} ;  {:<10} \n".format(Reactant1[j],"",Product1[j],"",pre_exp, pre_exp, Ea[j],Eb[j] )
            
            inp_file.write(line)    
        inp_file.write("\n\n&settings\nTYPE = SEQUENCERUN\nUSETIMESTAMP = 0\nPRESSURE = {}".format(P))
        inp_file.write("\nPOTAXIS=1\nDEBUG=0\nNETWORK_RATES=1\nNETWORK_FLUX=1")
        inp_file.write('\n\n&runs\n')
        inp_file.write("# Temp; Potential;Time;AbsTol;RelTol\n")
        line2 = "{:<5};{:<5};{:<5.2e};{:<5};{:<5}".format(Temp,V,Time,Abstol,Reltol)
        inp_file.write(line2)   
        inp_file.close()    
        command = [
        r'\\wsl.localhost\\ubuntu\\home\\aakrane\\mkmcxx\\bin\\mkmcxx.exe',  # Path to the executable
        '-i',  # Argument for the executable
        'input_file.mkm'  # Input file
    ]
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        os.chdir("../")
        
    os.chdir("../") 
    