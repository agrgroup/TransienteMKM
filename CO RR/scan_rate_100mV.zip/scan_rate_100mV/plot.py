from solver_settings import V_list,pH_list
import os
import matplotlib.pyplot as plt
base_directory = os.getcwd()
for pH in pH_list:
    def get_val(V,path):
        path = path + "\\V_"+str(V) 
        l = os.listdir(path)
        for i in l:
            if i.startswith("run"):
                seq_name = i
        path = path + "\\"+ seq_name
        print(path)
        l = os.listdir(path)
        seq_name1 = 'range'
        path = path + "\\"+ seq_name1
        
        cov_file = open(path+"\\"+"coverage.dat")
        
        cov_val = []
        
        cov_lines = cov_file.readlines()
        
        adsorbate_keys = cov_lines[0].strip().split()
        
        cov_dat_dict = {}
        
        for key in adsorbate_keys:
            cov_dat_dict[key] = []
        
        for line in cov_lines[1:]:
            vals = line.strip().split()
            vals = list(map(lambda x : float(x), vals))
            c=0
            for key in adsorbate_keys:
                cov_dat_dict[key].append(vals[c])
                c+=1
                
        cov_file.close()
        return cov_dat_dict
    
    path1="pH_" + str(pH)
    path=os.path.join(base_directory,path1)
    covs = get_val(V_list[0],path)
    covs_relevant ={}

    for key in covs.keys():
        if '*' in key:
            covs_relevant[key] = covs[key]

    covs_all_dat = {}

    for V in V_list:
        covs_all_dat[V]= {}
        val = get_val(V,path)
        for key in covs_relevant.keys():
                covs_all_dat[V][key] = val[key][-1]

    normal = "0123456789+-="
    super_s = "⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼"
    super_script = str.maketrans(normal,super_s)


    def make_trans(x):
        normal = "0123456789"
        sub_s = "₀₁₂₃₄₅₆₇₈₉"
        res = x.maketrans(''.join(normal), ''.join(sub_s))
        res = x.translate(res)
        if '*' in res:
            res = res.rstrip('*')
            res = '*'+res
        return res

    from matplotlib import rc, rcParams
    temp ={}
    for key in covs_relevant.keys():
        temp[key] = []
        for V in V_list:
            val = covs_all_dat[V][key]
            temp[key].append(val)
            
    final_vals = {}
    for key in temp.keys():
        val = temp[key]
        if max(val) <= 1 and min(val) >= 1e-20:
            final_vals[key] = temp[key]
            #val[:] = [x / Catalyst_Loading for x in val]
            #plt.plot(T_list, val,c=colour_dict[key], marker=markers_dict[key], label= make_trans(key), linewidth=2)
            plt.plot(V_list, val, label= make_trans(key), linewidth=2)

    #         plt.title(key)
        plt.xlabel('Potential (V)', fontsize = 16, fontweight='bold')
        plt.ylabel('Coverages', fontsize = 16,  fontweight='bold')
    legend_properties = {'weight':'bold'}
    leg=plt.legend(bbox_to_anchor=(1.38,0.5),loc='right', prop=legend_properties,fontsize = 18)
    # bbox_to_anchor=(1.38,1)
    leg.get_frame().set_edgecolor('black')
    leg.get_frame().set_linewidth(2.0)
    plt.xticks(fontweight='bold',fontsize= '18')
    plt.yticks(fontweight='bold',fontsize= '18')
    plt.title('pH = '+str(pH), fontsize = 20, fontweight='bold')
    rc('axes', linewidth=2)
    plt.show()