from dependencies import *
from path import *
from data_extract import *
from solver_settings import *
from inp_file_gen import *
def main():
    
    return

if __name__=="__main__":
    main()       