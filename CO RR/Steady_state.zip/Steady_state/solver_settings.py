## solver settings & MKM parameters
pH_list=[7,13]
V_list=[0,-0.1,-0.2,-0.3,-0.4,-0.5,-0.6,-0.7,-0.8,-0.9,-1] ##Potential with which barriers are referenced
#V_list=[0,-0.1,-0.2,-0.3]
Temp=298
Time=1e15
Abstol=1e-20
Reltol=1e-10